#include "ParticleManager.h"
#include "Camera.h"
#include <algorithm> // std::min用
#include <cassert>

using namespace Logger;

// 定数定義
const uint32_t ParticleManager::kMaxParticle = 512;

ParticleManager* ParticleManager::instance = nullptr;

ParticleManager* ParticleManager::GetInstance() {
	if (instance == nullptr) {
		instance = new ParticleManager;
	}
	return instance;
}

void ParticleManager::Finalize() {
	// インスタンスリソースの破棄
	for (auto& group : particleGroups_) {
		group.second.instanceResource.Reset();
	}
	particleGroups_.clear();

	// パイプラインの破棄（ここが漏れている可能性が高いです）
	rootSignature.Reset();
	graphicsPipelineState.Reset();

	delete instance;
	instance = nullptr;
}
void ParticleManager::Initialize(DirectXCommon* dxCommon) {

	// 1. ポインタ保存
	dxCommon_ = dxCommon;
	srvManager_ = SrvManager::GetInstance();

	// 2. ランダムエンジン初期化
	std::random_device seedGenerator;
	randomEngine_ = std::mt19937(seedGenerator());

	// 3. 頂点データの初期化 (main (2).cpp の VertexData 構造体に合わせる)
	// POSITION(float4), TEXCOORD(float2), NORMAL(float3)
	// ParticleManager.cpp の Initialize 関数内

	// 3. 頂点データの初期化
	vertices_.resize(6);

	// 左下
	vertices_[0] = VertexData{
	    {-0.5f, -0.5f, 0.0f, 1.0f},
        {0.0f, 1.0f},
        {0.0f, 0.0f, -1.0f}
    };
	// 左上
	vertices_[1] = VertexData{
	    {-0.5f, 0.5f, 0.0f, 1.0f},
        {0.0f, 0.0f},
        {0.0f, 0.0f, -1.0f}
    };
	// 右下
	vertices_[2] = VertexData{
	    {0.5f, -0.5f, 0.0f, 1.0f},
        {1.0f, 1.0f},
        {0.0f, 0.0f, -1.0f}
    };
	// 左上
	vertices_[3] = VertexData{
	    {-0.5f, 0.5f, 0.0f, 1.0f},
        {0.0f, 0.0f},
        {0.0f, 0.0f, -1.0f}
    };
	// 右上
	vertices_[4] = VertexData{
	    {0.5f, 0.5f, 0.0f, 1.0f},
        {1.0f, 0.0f},
        {0.0f, 0.0f, -1.0f}
    };
	// 右下
	vertices_[5] = VertexData{
	    {0.5f, -0.5f, 0.0f, 1.0f},
        {1.0f, 1.0f},
        {0.0f, 0.0f, -1.0f}
    };
	// 4. 頂点リソース生成
	vertexResource_ = dxCommon_->CreateBufferResource(sizeof(VertexData) * 6);

	// 5. VBV生成
	vertexBufferView_.BufferLocation = vertexResource_->GetGPUVirtualAddress();
	vertexBufferView_.SizeInBytes = sizeof(VertexData) * 6;
	vertexBufferView_.StrideInBytes = sizeof(VertexData);

	// 6. データ転送
	VertexData* mapped = nullptr;
	vertexResource_->Map(0, nullptr, reinterpret_cast<void**>(&mapped));
	std::memcpy(mapped, vertices_.data(), sizeof(VertexData) * vertices_.size());
	vertexResource_->Unmap(0, nullptr);

	// パイプライン生成
	CreatePipelineState();
}

void ParticleManager::CreateParticleGroup(const std::string& groupName, const std::string& textureFilePath) {

	// 登録済みチェック
	if (particleGroups_.find(groupName) != particleGroups_.end()) {
		assert(false && "ParticleGroup name already exists!");
		return;
	}

	// グループ作成
	ParticleGroup newGroup{};
	particleGroups_[groupName] = std::move(newGroup);
	ParticleGroup& group = particleGroups_[groupName];

	// マテリアル設定
	group.material.textureFilePath = textureFilePath;
	TextureManager::GetInstance()->LoadTexture(textureFilePath);
	group.material.textureIndex = TextureManager::GetInstance()->GetSrvIndex(textureFilePath);

	// インスタンシング用リソース生成
	const uint32_t maxInstance = kMaxParticle;
	uint32_t bufferSize = sizeof(ParticleForGPU) * maxInstance;

	group.instanceResource = dxCommon_->CreateBufferResource(bufferSize);

	// Mapしてポインタ保持
	group.instanceResource->Map(0, nullptr, reinterpret_cast<void**>(&group.instanceDataPtr));

	// SRV生成
	group.instanceSrvIndex = srvManager_->Allocate();

	D3D12_SHADER_RESOURCE_VIEW_DESC srvDesc{};
	srvDesc.Format = DXGI_FORMAT_UNKNOWN;
	srvDesc.ViewDimension = D3D12_SRV_DIMENSION_BUFFER;
	srvDesc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
	srvDesc.Buffer.FirstElement = 0;
	srvDesc.Buffer.NumElements = maxInstance;
	srvDesc.Buffer.StructureByteStride = sizeof(ParticleForGPU);
	srvDesc.Buffer.Flags = D3D12_BUFFER_SRV_FLAG_NONE;

	srvManager_->CreateSRVforStructuredBuffer(group.instanceSrvIndex, group.instanceResource.Get(), srvDesc.Buffer.NumElements, srvDesc.Buffer.StructureByteStride);

	group.instanceCount = 0;
	// ID3D12Resource* texRes = TextureManager::GetInstance()->GetResource(textureFilePath);

	// 【追加】テクスチャを COPY_DEST から PIXEL_SHADER_RESOURCE へ遷移させる
	D3D12_RESOURCE_BARRIER barrier{};
	barrier.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
	barrier.Transition.pResource = TextureManager::GetInstance()->GetResource(textureFilePath).Get();
	barrier.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST;
	barrier.Transition.StateAfter = D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE;
	barrier.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;

	//dxCommon_->GetCommandList()->ResourceBarrier(1, &barrier);
}

// ==========================================
// ルートシグネチャ生成 (main (2).cpp の構成を参考に整理)
// ==========================================
void ParticleManager::CreateRootSignature() {
	HRESULT hr;

	// [0] テクスチャ (t0)
	D3D12_DESCRIPTOR_RANGE descriptorRangeTexture[1] = {};
	descriptorRangeTexture[0].BaseShaderRegister = 0;
	descriptorRangeTexture[0].NumDescriptors = 1;
	descriptorRangeTexture[0].RangeType = D3D12_DESCRIPTOR_RANGE_TYPE_SRV;
	descriptorRangeTexture[0].OffsetInDescriptorsFromTableStart = D3D12_DESCRIPTOR_RANGE_OFFSET_APPEND;

	// [1] StructuredBuffer (t1)
	D3D12_DESCRIPTOR_RANGE descriptorRangeData[1] = {};
	descriptorRangeData[0].BaseShaderRegister = 1;
	descriptorRangeData[0].NumDescriptors = 1;
	descriptorRangeData[0].RangeType = D3D12_DESCRIPTOR_RANGE_TYPE_SRV;
	descriptorRangeData[0].OffsetInDescriptorsFromTableStart = D3D12_DESCRIPTOR_RANGE_OFFSET_APPEND;

	// ルートパラメータ
	D3D12_ROOT_PARAMETER rootParameters[2] = {};

	// Param 0: Texture
	rootParameters[0].ParameterType = D3D12_ROOT_PARAMETER_TYPE_DESCRIPTOR_TABLE;
	rootParameters[0].ShaderVisibility = D3D12_SHADER_VISIBILITY_PIXEL;
	rootParameters[0].DescriptorTable.pDescriptorRanges = descriptorRangeTexture;
	rootParameters[0].DescriptorTable.NumDescriptorRanges = _countof(descriptorRangeTexture);

	// Param 1: Instancing Data
	rootParameters[1].ParameterType = D3D12_ROOT_PARAMETER_TYPE_DESCRIPTOR_TABLE;
	rootParameters[1].ShaderVisibility = D3D12_SHADER_VISIBILITY_VERTEX;
	rootParameters[1].DescriptorTable.pDescriptorRanges = descriptorRangeData;
	rootParameters[1].DescriptorTable.NumDescriptorRanges = _countof(descriptorRangeData);

	// サンプラー
	D3D12_STATIC_SAMPLER_DESC staticSamplers[1] = {};
	staticSamplers[0].Filter = D3D12_FILTER_MIN_MAG_MIP_LINEAR;
	staticSamplers[0].AddressU = D3D12_TEXTURE_ADDRESS_MODE_WRAP;
	staticSamplers[0].AddressV = D3D12_TEXTURE_ADDRESS_MODE_WRAP;
	staticSamplers[0].AddressW = D3D12_TEXTURE_ADDRESS_MODE_WRAP;
	staticSamplers[0].ComparisonFunc = D3D12_COMPARISON_FUNC_NEVER;
	staticSamplers[0].MaxLOD = D3D12_FLOAT32_MAX;
	staticSamplers[0].ShaderRegister = 0;
	staticSamplers[0].ShaderVisibility = D3D12_SHADER_VISIBILITY_PIXEL;

	D3D12_ROOT_SIGNATURE_DESC descriptionRootSignature{};
	descriptionRootSignature.Flags = D3D12_ROOT_SIGNATURE_FLAG_ALLOW_INPUT_ASSEMBLER_INPUT_LAYOUT;
	descriptionRootSignature.pParameters = rootParameters;
	descriptionRootSignature.NumParameters = _countof(rootParameters);
	descriptionRootSignature.pStaticSamplers = staticSamplers;
	descriptionRootSignature.NumStaticSamplers = _countof(staticSamplers);

	// シリアライズ
	Microsoft::WRL::ComPtr<ID3DBlob> signatureBlob = nullptr;
	Microsoft::WRL::ComPtr<ID3DBlob> errorBlob = nullptr;
	hr = D3D12SerializeRootSignature(&descriptionRootSignature, D3D_ROOT_SIGNATURE_VERSION_1, &signatureBlob, &errorBlob);
	if (FAILED(hr)) {
		Log(reinterpret_cast<const char*>(errorBlob->GetBufferPointer()));
		assert(false);
	}

	hr = dxCommon_->GetDevice()->CreateRootSignature(0, signatureBlob->GetBufferPointer(), signatureBlob->GetBufferSize(), IID_PPV_ARGS(&rootSignature));
	assert(SUCCEEDED(hr));
}

// ==========================================
// PSO生成 (main (2).cpp の設定値を反映)
// ==========================================
void ParticleManager::CreatePipelineState() {
	HRESULT hr;

	CreateRootSignature();

	// InputLayout (main (2).cpp の VertexData 構造体に合致させる)
	D3D12_INPUT_ELEMENT_DESC inputElementDescs[] = {
	    {"POSITION", 0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, D3D12_APPEND_ALIGNED_ELEMENT, D3D12_INPUT_CLASSIFICATION_PER_VERTEX_DATA, 0},
	    {"TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT,       0, D3D12_APPEND_ALIGNED_ELEMENT, D3D12_INPUT_CLASSIFICATION_PER_VERTEX_DATA, 0},
	    {"NORMAL",   0, DXGI_FORMAT_R32G32B32_FLOAT,    0, D3D12_APPEND_ALIGNED_ELEMENT, D3D12_INPUT_CLASSIFICATION_PER_VERTEX_DATA, 0},
	};
	D3D12_INPUT_LAYOUT_DESC inputLayoutDesc{};
	inputLayoutDesc.pInputElementDescs = inputElementDescs;
	inputLayoutDesc.NumElements = _countof(inputElementDescs);

	// BlendState (main (2).cpp の kBlendModeNormal に相当する設定)
	D3D12_BLEND_DESC blendDesc{};
	blendDesc.RenderTarget[0].RenderTargetWriteMask = D3D12_COLOR_WRITE_ENABLE_ALL;
	blendDesc.RenderTarget[0].BlendEnable = TRUE;
	blendDesc.RenderTarget[0].SrcBlend = D3D12_BLEND_SRC_ALPHA;
	blendDesc.RenderTarget[0].BlendOp = D3D12_BLEND_OP_ADD;
	blendDesc.RenderTarget[0].DestBlend = D3D12_BLEND_INV_SRC_ALPHA;
	blendDesc.RenderTarget[0].SrcBlendAlpha = D3D12_BLEND_ONE;
	blendDesc.RenderTarget[0].BlendOpAlpha = D3D12_BLEND_OP_ADD;
	blendDesc.RenderTarget[0].DestBlendAlpha = D3D12_BLEND_ZERO;

	// RasterizerState (main (2).cpp と同じ設定)
	D3D12_RASTERIZER_DESC rasterizerDesc{};
	rasterizerDesc.CullMode = D3D12_CULL_MODE_BACK; // main(2).cppではBACKになっている
	rasterizerDesc.FillMode = D3D12_FILL_MODE_SOLID;

	// Shader Compile
	Microsoft::WRL::ComPtr<IDxcBlob> vertexShaderBlob = dxCommon_->CompileShader(L"Resources/Shader/Particle.VS.hlsl", L"vs_6_0");
	assert(vertexShaderBlob != nullptr);
	Microsoft::WRL::ComPtr<IDxcBlob> pixelShaderBlob = dxCommon_->CompileShader(L"Resources/Shader/Particle.PS.hlsl", L"ps_6_0");
	assert(pixelShaderBlob != nullptr);

	// PSO設定
	D3D12_GRAPHICS_PIPELINE_STATE_DESC psoDesc{};
	psoDesc.pRootSignature = rootSignature.Get();
	psoDesc.InputLayout = inputLayoutDesc;
	psoDesc.BlendState = blendDesc;
	psoDesc.RasterizerState = rasterizerDesc;
	psoDesc.VS = {vertexShaderBlob->GetBufferPointer(), vertexShaderBlob->GetBufferSize()};
	psoDesc.PS = {pixelShaderBlob->GetBufferPointer(), pixelShaderBlob->GetBufferSize()};

	// DepthStencilState (main (2).cpp と同じ設定)
	D3D12_DEPTH_STENCIL_DESC depthStencilDesc{};
	depthStencilDesc.DepthEnable = true;
	depthStencilDesc.DepthWriteMask = D3D12_DEPTH_WRITE_MASK_ALL; // main(2).cppではALLになっている
	depthStencilDesc.DepthFunc = D3D12_COMPARISON_FUNC_LESS_EQUAL;
	psoDesc.DepthStencilState = depthStencilDesc;

	// 【重要】DSVフォーマット (main (2).cpp に合わせる)
	psoDesc.DSVFormat = DXGI_FORMAT_D24_UNORM_S8_UINT;

	psoDesc.NumRenderTargets = 1;
	psoDesc.RTVFormats[0] = DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;
	psoDesc.PrimitiveTopologyType = D3D12_PRIMITIVE_TOPOLOGY_TYPE_TRIANGLE;
	psoDesc.SampleDesc.Count = 1;
	psoDesc.SampleMask = D3D12_DEFAULT_SAMPLE_MASK;

	hr = dxCommon_->GetDevice()->CreateGraphicsPipelineState(&psoDesc, IID_PPV_ARGS(&graphicsPipelineState));

	if (FAILED(hr)) {
		OutputDebugStringA("Error: Failed to create GraphicsPipelineState for Particle.\n");
		assert(false);
	}
}

void ParticleManager::Draw(Camera* camera) {
	auto commandList = dxCommon_->GetCommandList();
	SrvManager::GetInstance()->preDraw();

	commandList->SetPipelineState(graphicsPipelineState.Get());
	commandList->SetGraphicsRootSignature(rootSignature.Get());
	commandList->IASetPrimitiveTopology(D3D_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
	commandList->IASetVertexBuffers(0, 1, &vertexBufferView_);

	Matrix4x4 viewProjection = camera->GetViewProjectionMatrix();
	Matrix4x4 billboardMatrix = camera->GetWorldMatrix();
	billboardMatrix.m[3][0] = 0.0f;
	billboardMatrix.m[3][1] = 0.0f;
	billboardMatrix.m[3][2] = 0.0f;

	for (auto& [name, group] : particleGroups_) {
		if (group.particles.empty())
			continue;

		uint32_t numInstance = std::min<uint32_t>(static_cast<uint32_t>(group.particles.size()), kMaxParticle);
		uint32_t index = 0;

		for (const auto& particle : group.particles) {
			if (index >= numInstance)
				break;

			Matrix4x4 scaleMatrix = MakeScaleMatrix(particle.transform.scale);
			Matrix4x4 rotateMatrix = MakeRotateXYZMatrix(particle.transform.rotate); // 回転行列
			Matrix4x4 translateMatrix = MakeTranslateMatrix(particle.transform.translate);

			// ビルボード処理を入れる場合はここで rotateMatrix を billboardMatrix に置き換える
			Matrix4x4 worldMatrix = Multiply(scaleMatrix, Multiply(billboardMatrix, translateMatrix));

			//Matrix4x4 worldMatrix = Multiply(scaleMatrix, Multiply(rotateMatrix, translateMatrix));
			Matrix4x4 wvp = Multiply(worldMatrix, viewProjection);

			group.instanceDataPtr[index].WVP = wvp;
			group.instanceDataPtr[index].world = worldMatrix;
			group.instanceDataPtr[index].color = particle.color;

			index++;
		}

		group.instanceCount = numInstance;

		if (group.instanceCount > 0) {
			// [0] Texture
			commandList->SetGraphicsRootDescriptorTable(0, srvManager_->GetGPUDescriptorHandle(group.material.textureIndex));
			// [1] Data
			commandList->SetGraphicsRootDescriptorTable(1, srvManager_->GetGPUDescriptorHandle(group.instanceSrvIndex));

			commandList->DrawInstanced(6, group.instanceCount, 0, 0);
		}
	}
}

// Update, Emit関数は以前のままでOK
void ParticleManager::Update() {
	for (auto& groupPair : particleGroups_) {
		ParticleGroup& group = groupPair.second;
		group.instanceCount = 0;

		for (auto it = group.particles.begin(); it != group.particles.end();) {
			if (it->currentTime >= it->lifeTime) {
				it = group.particles.erase(it);
				continue;
			}
			it->transform.translate.x += it->velocity.x;
			it->transform.translate.y += it->velocity.y;
			it->transform.translate.z += it->velocity.z;

			float alpha = 1.0f - (it->currentTime / it->lifeTime);
			it->color.w = alpha;

			it->currentTime += 1.0f / 60.0f;
			++it;
		}
	}
}

void ParticleManager::Emit(const std::string& groupName, const Vector3& position, uint32_t count) {
	if (particleGroups_.find(groupName) == particleGroups_.end())
		return;

	ParticleGroup& group = particleGroups_[groupName];
	std::uniform_real_distribution<float> distPos(-1.0f, 1.0f);
	std::uniform_real_distribution<float> distVel(-1.0f, 1.0f);
	std::uniform_real_distribution<float> distColor(0.5f, 1.0f);

	for (uint32_t i = 0; i < count; ++i) {
		Particle newParticle;
		Vector3 randomPos = {distPos(randomEngine_) * 0.5f, distPos(randomEngine_) * 0.5f, distPos(randomEngine_) * 0.5f};
		newParticle.transform.translate = {position.x + randomPos.x, position.y + randomPos.y, position.z + randomPos.z};

		Vector3 randomVel = {distVel(randomEngine_) * 0.1f, distVel(randomEngine_) * 0.1f, distVel(randomEngine_) * 0.1f};
		newParticle.velocity = randomVel;

		newParticle.transform.scale = {1.0f, 1.0f, 1.0f};
		newParticle.transform.rotate = {0.0f, 0.0f, 0.0f};
		newParticle.color = {distColor(randomEngine_), distColor(randomEngine_), distColor(randomEngine_), 1.0f};
		newParticle.lifeTime = 2.0f;
		newParticle.currentTime = 0.0f;

		group.particles.push_back(newParticle);
	}
}