#include "Game.h"
#include "struct.h"
#include <DbgHelp.h> // MiniDumpWriteDump の宣言用
#include <Windows.h>
#include <strsafe.h> // StringCchPrintfW を使っているなら
#include <utility>
#include "SceneFactory.h"
using namespace Logger;
using namespace StringUtility;
using namespace Microsoft::WRL;

void Game::Initialize() {

	FlameWork::Initialize();
	camera = std::make_unique<Camera>();
	camera->SetTranslate({0.0f, 0.0f, -20.0f});
	Object3dCommon::GetInstance()->SetDefaultCamera(camera.get());
	// 1. 初期化
	// 1. パーティクルグループを作成（テクスチャのロードなどもここで行われます）
	// 引数：グループ名, テクスチャパス
	// 2. グループ作成（テクスチャロード）
	ParticleManager::GetInstance()->CreateParticleGroup("Smoke", "Resources/uvChecker.png");
	ParticleManager::GetInstance()->CreateParticleGroup("Fire", "Resources/uvChecker.png");
	ParticleManager::GetInstance()->SetCamera(camera.get());
	sceneFactory = new SceneFactory();
	SceneManager::GetInstance()->SetSceneFactory(sceneFactory);
	SceneManager::GetInstance()->ChengeScene("TITLE");


}

void Game::Update() {
	// メッセージを取得
	FlameWork::Update();
	Input::GetInstance()->Update();

	// シーンの更新
	SceneManager::GetInstance()->Update();
	
	if (Input::GetInstance()->TriggerKey(DIK_ESCAPE)) {
		endRequest = true;
	}



}

void Game::Draw() {
#pragma region コマンドリストのリセット

	SpriteCommon::GetInstance()->GetDxCommon()->PreDraw();
	// モデルの描画
	Object3dCommon::GetInstance()->SetDraw();
	SceneManager::GetInstance()->Draw3D();
	// スプライトの描画
	SpriteCommon::GetInstance()->SetDraw();
	SceneManager::GetInstance()->Draw2D();

	SpriteCommon::GetInstance()->GetDxCommon()->PostDraw();
#pragma endregion
}

void Game::Finalize() {
	// ImGuiの終了処理
	// --- 終了処理 ---
	Audio::GetInstance().Finalize();
	FlameWork::Finalize();
	

}

